import 'rc-drawer/assets/index.css';
import 'antd/lib/auto-complete/style/index.css';
import 'medium-editor/dist/css/medium-editor.css';
import 'medium-editor/dist/css/themes/default.css';
// import 'rc-editor-list/assets/index.css';
import 'codemirror/lib/codemirror.css';
import 'codemirror/theme/ambiance.css';
import 'codemirror/addon/hint/show-hint.css';
import './index.less';
